About Academi Moodle theme
=========================

This is Responsive Bootstrapbase Moodle Theme



* package   Moodle Academi Theme

* copyright 2015 onwards www.lmsthemes.com

* authors   Nephzat Dev Team


Supported moodle versions

---------------
Compatible with Moodle 2.6,2.7,2.8 and 2.9


Supported browsers

------------------

IE9+

Recent versions of all modern browsers


Academi theme - Installation steps
================================

1) On your download pacakge, you will find theme_academi.zip

2) Unzip - theme_academi.zip, you will get folder 'academi'

3) Copy folder 'academi' and put into theme folder of your moodle system

4) Next login as Site administrator

5) Go to 'Site administration' -> 'Notifications' , here on 'Plugins check' page you will find both the items.

6) Click the "Upgrade Moodle database now" button displayed on bottom of the page

7) You will get success message once the plugins installed successfully.

8) By clicking "Continue" button on success page , you will get options to change the academi theme settings.
   You can modify the settings later too :-)


Steps to set academi theme as default theme for your moodle system
==================================================================

1) Login as site administrator

2) Go to Site administration -> Appearance -> Themes ->
 Theme selector

3) Click the "Change theme" button for device type as "Default"

4) It will list all the available themes for "Default device"

5) Then click "Use theme" button on "Academi theme"

6) Next click the "Continue" button ,thats it. 

Cheers,you have done it !!!


If you need any support related to this theme , kindly send a mail to info@nephzat.com

